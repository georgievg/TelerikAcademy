﻿using System;
using System.Linq;

namespace FreeContentCatalog
{
    public enum CommandAction
    {
        AddBook,
        AddMovie,
        AddSong,
        AddApplication,
        Update,
        Find,
    }
}